package denoflionsx.denLib.CoreMod.Transformers;

import denoflionsx.denLib.CoreMod.denLibCoreMod;

public class TransformerBlockLeave extends TransformerBase{

    public TransformerBlockLeave() {
        this.setObfName(denLibCoreMod.LeavesMapping);
    }
}
