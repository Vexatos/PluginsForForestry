package denoflionsx.denLib.Interfaces;

public interface IDenCore {
    
    public void setupItems();
    
    public void setupConfig();
    
    public void setupBlocks();
    
    public void preloadTextures();
    
}
