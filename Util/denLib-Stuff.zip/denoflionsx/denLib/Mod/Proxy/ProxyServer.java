package denoflionsx.denLib.Mod.Proxy;

public class ProxyServer extends Proxy{



}
