package denoflionsx.denLib.Mod.API;

import denoflionsx.denLib.Mod.API.Interfaces.ILeavesDropManager;

public class denLibManagers {
    
    // Add drops to leaves.
    
    public static ILeavesDropManager LeavesDropManager;
    
}
