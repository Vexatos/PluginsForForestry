package denoflionsx.denLib.Mod.Version;

public class Version {
    
    public static final String name = "denLib";
    public static final String version = "@version@";
    public static final String ProxyClient = "denoflionsx.denLib.Mod.Proxy.ProxyClient";
    public static final String ProxyServer = "denoflionsx.denLib.Mod.Proxy.ProxyServer";
    
}
