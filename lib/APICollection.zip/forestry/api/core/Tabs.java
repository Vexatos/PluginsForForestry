package forestry.api.core;

import net.minecraft.creativetab.CreativeTabs;

public class Tabs {

	public static CreativeTabs tabApiculture;
	public static CreativeTabs tabArboriculture;

}
