package forestry.api.arboriculture;

import forestry.api.genetics.IAlleleEffect;

/**
 * Simple allele encapsulating a leaf effect. (Not implemented)
 */
public interface IAlleleLeafEffect extends IAlleleEffect {

}
