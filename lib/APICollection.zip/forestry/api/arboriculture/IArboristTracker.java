package forestry.api.arboriculture;

import forestry.api.genetics.IBreedingTracker;

public interface IArboristTracker extends IBreedingTracker {

}
