package forestry.api.arboriculture;

public class TreeManager {
	public static int treeSpeciesCount = 0;
	public static ITreeInterface treeInterface;
	public static ITreeBreedingManager breedingManager;
}
