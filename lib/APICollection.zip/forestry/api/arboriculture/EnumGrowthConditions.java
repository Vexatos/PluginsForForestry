package forestry.api.arboriculture;

public enum EnumGrowthConditions {
	HOSTILE, PALTRY, NORMAL, GOOD, EXCELLENT
}
