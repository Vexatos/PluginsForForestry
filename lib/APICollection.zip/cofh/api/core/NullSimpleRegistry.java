
package cofh.api.core;

public class NullSimpleRegistry implements ISimpleRegistry {

    @Override
    public boolean register(String playerName, String URL) {

        return false;
    }

}
