
package cofh.api.core;

public interface IInitializer {

    public void initialize();

    public void loadRecipes();

}
