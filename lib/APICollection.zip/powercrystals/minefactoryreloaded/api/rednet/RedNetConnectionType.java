package powercrystals.minefactoryreloaded.api.rednet;

public enum RedNetConnectionType
{
	None,
	CableSingle,
	PlateSingle,
	CableAll,
	PlateAll
}
