package powercrystals.minefactoryreloaded.api;

/**
 * @author PowerCrystals
 * Defines a tool that can rotate MFR machines. Implement on an Item class. Requires no additional work on your part. 
 */
public interface IToolHammer
{
}
