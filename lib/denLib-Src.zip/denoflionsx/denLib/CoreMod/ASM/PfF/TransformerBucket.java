package denoflionsx.denLib.CoreMod.ASM.PfF;

import cpw.mods.fml.relauncher.IClassTransformer;
import denoflionsx.denLib.CoreMod.ASM.ClassOverride;
import denoflionsx.denLib.CoreMod.denLibCore;
import denoflionsx.denLib.Lib.denLib;

public class TransformerBucket implements IClassTransformer {
    
    private String mapping;

    public TransformerBucket() {
        mapping = denLib.StringUtils.readFileContentsAutomated(null, "bucket.mapping", this)[0];
    }

    @Override
    public byte[] transform(String name, String transformedName, byte[] bytes) {
        if (name.equals(mapping)) {
            bytes = ClassOverride.Override(name, bytes, mapping, denLibCore.location);
        }
        return bytes;
    }
}
