package denoflionsx.denLib.CoreMod;

import cpw.mods.fml.common.FMLLog;
import cpw.mods.fml.relauncher.IFMLLoadingPlugin;
import denoflionsx.denLib.CoreMod.ASM.PfF.TransformerBucket;
import denoflionsx.denLib.CoreMod.Updater.UpdateManager;
import java.io.File;
import java.util.Map;

public class denLibCore implements IFMLLoadingPlugin {
    
    public static UpdateManager updater;
    public static File check = new File("denLibUpdateCheck.bin");
    public static final String build_number = "@BUILD_NUMBER@";
    public static File location;

    @Override
    public String[] getASMTransformerClass() {
        return new String[]{TransformerBucket.class.getName()};
    }

    @Override
    public String[] getLibraryRequestClass() {
        return null;
    }

    @Override
    public String getModContainerClass() {
        return null;
    }

    @Override
    public String getSetupClass() {
        return null;
    }

    @Override
    public void injectData(Map<String, Object> data) {
        location = (File) data.get("coremodLocation");
        updater = new UpdateManager();
        updater.doUpdate();
        //LibraryManager.instance.runLibraryChecks();
    }
    
    public static void print(String msg){
        FMLLog.info("[denLibCore]: " + msg);
    }
}
