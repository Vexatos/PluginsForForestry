package denoflionsx.denLib.Mod.Event;

import java.lang.annotation.Annotation;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Arrays;

public class DenEventHandler {

    public static DenEventHandler instance;
    private ArrayList<Object> listeners;

    public static void create(){
        instance = new DenEventHandler();
    }
    
    public void register(Object c) {
        listeners.add(c);
    }

    public void processEvent(BucketDumpedEvent e) {
        for (Object o : listeners) {
            Class c = o.getClass();
            for (Method m : c.getDeclaredMethods()) {
                for (Annotation a : m.getDeclaredAnnotations()) {
                    if (a instanceof DenListen) {
                        if (Arrays.equals(m.getParameterTypes(), new Object[]{BucketDumpedEvent.class})) {
                            try {
                                m.invoke(o, e);
                            } catch (Exception ex) {
                                ex.printStackTrace();
                            }
                        }
                    }
                }
            }
        }
    }
}
