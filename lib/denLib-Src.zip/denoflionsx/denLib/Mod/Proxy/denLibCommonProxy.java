package denoflionsx.denLib.Mod.Proxy;

public class denLibCommonProxy extends denLibProxy{
    
}
