package denoflionsx.denLib.Mod.Proxy;

public class denLibClientProxy extends denLibProxy {
}
