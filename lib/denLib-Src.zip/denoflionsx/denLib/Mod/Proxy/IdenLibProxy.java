package denoflionsx.denLib.Mod.Proxy;

public interface IdenLibProxy {
    
    public void print(String msg);
    
    public void warning(String warning);
    
    public void registerForgeSubscribe(Object o);
    
    public void sendMessageToPlayer(String msg);
    
    public void registerDenListen(Object o);
    
}
