package net.minecraftforge.event;



public interface IEventListener
{
    public void invoke(Event event);
}
